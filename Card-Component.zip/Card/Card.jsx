import style from './Card.module.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleInfo, faStar } from '@fortawesome/free-solid-svg-icons'
import { faOpencart } from '@fortawesome/free-brands-svg-icons'

export default function Card() {
  return (
    <div className={style.card}>
        <div className={style.cardImg}>
            <img src="https://img.freepik.com/free-photo/bottle-perfume-with-word-perfume-it_1340-37484.jpg" alt="" />
        </div>
        <div className={style.cardInfo}>

          <div className={style.productDetails}>
              <span><FontAwesomeIcon className={style.detailsIcon} icon={faCircleInfo} /></span>
              <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus odio animi ad ducimus ipsum sed voluptas eligendi optio officia architecto. Vero unde possimus, itaque voluptas quasi dolores facilis delectus nemo! <a href="#">See More &#10149;</a></p>

              
          </div>


          <div className={style.cardHeader}>
              <h2 className={style.cardTitle}>Perfume</h2>
              <span className={style.rating}>
              <FontAwesomeIcon className={style.star} icon={faStar} />
              <FontAwesomeIcon className={style.star} icon={faStar} />
              <FontAwesomeIcon className={style.star} icon={faStar} />
              <FontAwesomeIcon className={style.star} icon={faStar} />
              <FontAwesomeIcon className={style.star} icon={faStar} />
              </span>
        </div>


          <div className={style.cardFooter}>
              <div>
              <button className={style.AddToCartBtn}>Add To Cart <FontAwesomeIcon className={style.cartIcon} icon={faOpencart} /></button>
              </div>
              <h5 className={style.price}>$299.99</h5>
          </div>
          
        </div>

    </div>
  )
}
